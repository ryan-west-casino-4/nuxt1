<template>
  <div class="font-sans text-gray-900 antialiased"><Nuxt /></div>
</template>
